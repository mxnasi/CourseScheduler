
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manas
 */
public class StudentQueries {
    private static Connection connection;
    
    public static void addStudent(StudentEntry student){
        connection = DBConnection.getConnection();
        try{
            PreparedStatement ps = connection.prepareStatement("insert into app.student(StudentID, FirstName, LastName) values (?,?,?)");
            ps.setString(1, student.getStudentID());
            ps.setString(2, student.getFirstName());
            ps.setString(3, student.getLastName());
            ps.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        } 
    }
    
    public static ArrayList<StudentEntry> getAllStudents() {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> studentList = new ArrayList<StudentEntry>();
        try{
            PreparedStatement ps = connection.prepareStatement("select * from app.student");
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()){
                StudentEntry s = new StudentEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3));
                studentList.add(s);
            }      
            connection.close();        
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return studentList;
    }
    
    public static StudentEntry getStudent(String studentID) {
        connection = DBConnection.getConnection();
        StudentEntry s = null;
        try{
            PreparedStatement ps = connection.prepareStatement("select * from app.student where studentID =");
            ps.setString(1, studentID);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()){
                s = new StudentEntry(resultSet.getString(1), resultSet.getString(2),resultSet.getString(3));
            }
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        
        return s;
    }
    
    
    public static void dropStudent(String studentID) {
        connection = DBConnection.getConnection();
        try{
            PreparedStatement ps = connection.prepareStatement("delete from app.student where studentID = ?");
            ps.setString(1, studentID);
            ps.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
 
  
}
