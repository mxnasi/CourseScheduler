/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manas
 */
public class StudentEntry {
    private String studentID;
    private String FirstName;
    private String LastName;
    
    public StudentEntry (String studentID, String FirstName, String LastName){
        this.studentID = studentID;
        this.FirstName = FirstName;
        this.LastName = LastName;
    }

    StudentEntry(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String getStudentID(){
        return studentID;
    }
    
    public String getFirstName(){
        return FirstName;
    }
    
    public String getLastName(){
        return LastName;
    }
}
