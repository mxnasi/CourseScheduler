import java.sql.Connection;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manas
 */

public class Semester {
    private String semester;
    private static Connection connection;
    private static ArrayList<String> Semester = new ArrayList<String>();
    private static PreparedStatement addSemester;
    private static PreparedStatement getSemester;
    private static ResultSet resultSet;
    
    
    
   public Semester (String semester){
       this.semester = semester;
   }
   
   public String getSemester(){
       return semester;
   }
}
