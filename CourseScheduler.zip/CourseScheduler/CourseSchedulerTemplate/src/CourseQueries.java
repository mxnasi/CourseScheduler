
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manas
 */
public class CourseQueries {
    
    private static Connection connection;    
     
    public static void addCourse(CourseEntry course){
        connection = DBConnection.getConnection();
        try{
            PreparedStatement ps = connection.prepareStatement("insert into app.course(semester, courseCode, Description, seats) values (?,?,?,?)");
            ps.setString(1, course.getSemester());
            ps.setString(2, course.getCourseCode());
            ps.setString(3, course.getCourseDescription());
            ps.setInt(4, course.getSeats());
            ps.executeUpdate();
            }
        catch(SQLException sqlException){
             sqlException.printStackTrace();
            }
       }
    
    public static ArrayList<String> getAllCourseCodes (String semester){
        connection = DBConnection.getConnection();
        ArrayList<String> coursecodes = new ArrayList<String>();
        try{
            PreparedStatement ps = connection.prepareStatement("select courseCode from mdas.course where semester = ?");
            ps.setString(1, semester);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()){
                coursecodes.add(resultSet.getString(1));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return coursecodes;
    }
    
    public static ArrayList<CourseEntry> getAllCourses(String semester){
        connection = DBConnection.getConnection();
        ArrayList<CourseEntry> courses = new ArrayList<CourseEntry>();
        try{
            PreparedStatement ps = connection.prepareStatement("select semester, courseCode, Description, seats from app.course where semester = ?");
            ps.setString(1, semester);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()){
                CourseEntry c = new CourseEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getInt(4));
                courses.add(c);
            }
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        
        return courses;
    }
    
    public static Integer getCourseSeats(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        Integer seat = 0;
        try{
            PreparedStatement ps = connection.prepareStatement("select semester, courseCode from app.course where semester = ?, courseCode = ?");
            ps.setString(1, semester);
            ps.setString(2, courseCode);
            ResultSet resultSet = ps.executeQuery();
                        
            while (resultSet.next()){
                seat = resultSet.getInt("seats");
            }
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
            
        return seat;  
        
    }
        
        
    public static void dropCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try{
            PreparedStatement ps = connection.prepareStatement("delete from app.course where courseCode = ?");
            ps.setString(1, courseCode);
            ps.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
       
     }
    
}
