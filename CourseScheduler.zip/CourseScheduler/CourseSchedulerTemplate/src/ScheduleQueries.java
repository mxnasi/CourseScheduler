/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Timestamp;
/**
 *
 * @author manas
 */
public class ScheduleQueries {
    
    private static Connection connection;
    
    private static ArrayList<String> ScheduleEntry = new ArrayList<String>(); //??
    private static PreparedStatement getScheduleByStudent;
    private static ResultSet resultSet;
    
    
    public static void addScheduleEntry(ScheduleEntry entry) {
        connection = DBConnection.getConnection();
        try{
           PreparedStatement ps = connection.prepareStatement("insert into app.Schedule (semester, courseCode, studentID, status) values (?,?,?,?)");
           ps.setString(1, entry.getSemester());
           ps.setString(2, entry.getCourseCode());
           ps.setString(3, entry.getStudentID());
           ps.setString(4, entry.getStatus());
           ps.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        
    }
    
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID) {
        connection = DBConnection.getConnection();
        ScheduleEntry s = null;
        ArrayList<ScheduleEntry> studentScheduleList = new ArrayList<ScheduleEntry>();
        try{
            PreparedStatement ps = connection.prepareStatement("select schedule from student where studentID = ?");
            ps.setString(1, studentID);
            ResultSet resultSet = ps.executeQuery();
            
            while((resultSet.next())){
               s = new ScheduleEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getTimestamp(5));
               studentScheduleList.add(s);
            }
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return studentScheduleList;
    }
    
    
    
    public static Integer getScheduledStudentCount(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        Integer scheduledStudentCount = 0;
        try{
            PreparedStatement ps = connection.prepareStatement("select count(a.studentID) count from app.schedule a,app.semester b where a.semester = b.name");
            ps.setString(1, semester);
            ps.setString(2, courseCode);
            ResultSet resultSet = ps.executeQuery();
                        
            while (resultSet.next()){
                scheduledStudentCount = Integer.valueOf(resultSet.getString("count"));
            }
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
            
        return scheduledStudentCount;  
        
       
       
    }
    
   
    
    
    
    
    
    
    
    
}
